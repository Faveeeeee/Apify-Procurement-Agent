# 🇳🇬 Nigerian SME Procurement Matcher AI Agent

An AI-powered Apify Actor designed to help Small and Medium Enterprises (SMEs) in Nigeria automatically discover, scrape, and evaluate procurement opportunities and tenders.

## 💡 What It Does
Finding and bidding for procurement opportunities in Nigeria often requires sifting through lengthy requirement documents and website listings. This AI Agent automates that entire process:
1. **Scrapes Target Websites:** Uses Apify web scraping tools to fetch live tender notices and procurement listings (e.g., TendersNigeria).
2. **Evaluates SME Capability:** Compares SME profiles (services, certifications, years of experience, location) against the specific criteria found in each tender.
3. **Generates Match Analysis:** Returns a structured evaluation containing a **Match Score (0-100)**, explicit **Matched Requirements**, and missing **Qualifications/Disqualifiers**.

## 🚀 How It Works
- **LangChain & OpenAI GPT-4o:** Powers the core reasoning engine using structured Pydantic outputs.
- **Apify Web Scraping Tools:** Dynamically extracts webpage content from target procurement URLs.
- **Pay Per Event (PPE):** Uses Apify's monetization framework (`actor-start` and `task-completed` events) to transparently charge per evaluation task.

---

## 📥 Input Schema

The Actor expects two main inputs in JSON format:

```json
{
  "sme_profile": {
    "company_name": "Lagos Tech Solutions",
    "services": ["Software Development", "Cloud Migration", "Cybersecurity"],
    "certifications": ["ISO 27001", "NITDA"],
    "years_experience": 4,
    "location": "Lagos"
  },
  "target_urls": [
    "[https://tendersnigeria.com](https://tendersnigeria.com)"
  ],

  📤 Output Schema
Results are stored directly in the Apify Dataset and can be downloaded as JSON, CSV, or Excel:
{
  "sme_name": "Lagos Tech Solutions",
  "evaluated_tenders": [
    {
      "tender_title": "Supply and Implementation of Cloud ERP Infrastructure",
      "tender_source_url": "[https://tendersnigeria.com](https://tendersnigeria.com)",
      "match_score": 85,
      "matched_requirements": [
        "Cloud Migration capability matched",
        "ISO 27001 Certification requirement satisfied"
      ],
      "missing_requirements": [
        "Tender requires 5+ years in business (SME has 4)"
      ],
      "reasoning": "Strong technical alignment on cloud infrastructure and security compliance. Slightly under on operating longevity requirement."
    }
  ]
}
💰 Pay Per Event (PPE) Integration
This Actor utilizes the Apify Pay Per Event pricing model:

actor-start: Triggered when the Actor initializes.

task-completed: Triggered upon successfully scraping, evaluating, and pushing dataset results.

Triggered via Apify SDK in Python:
await Actor.charge('actor-start')
# ... processing logic ...
await Actor.charge('task-completed')

🛠 Features & Storage
Apify SDK for Python: Interacts directly with platform datasets and key-value stores.

Dataset Storage: Multi-row structured outputs for easy export.

Key-Value Store: Saves complete JSON reports (response.json).

🏁 Getting Started
Set OPENAI_API_KEY in the Actor's Integrations / Environment Variables.

Pass the SME Profile and target URL in the Input tab.

Click Run and view results under the Dataset tab.


### Final Pre-Build Checklist 
- All JSON files updated (`input_schema.json`, `dataset_schema.json`, `key_value_store_schema.json`, `output_schema.json`, `pay_per_event.json`).
- Python files updated (`my_actor/models.py`, `my_actor/main.py`, `my_actor/__main__.py`).
- Added packages to `requirements.txt`.
- Set `OPENAI_API_KEY` under **Integrations / Environment Variables**.
- Click **Save & build**. Once built, hit **Run** to generate the demo.
  "modelName": "gpt-4o-mini"
}