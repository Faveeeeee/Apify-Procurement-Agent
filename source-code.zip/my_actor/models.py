"""Module defines Pydantic models for this project.

These models are used mainly for the structured tool and LLM outputs.
Resources:
- https://docs.pydantic.dev/latest/concepts/models/
"""

from typing import List
from pydantic import BaseModel, Field

class TenderMatchResult(BaseModel):
    tender_title: str = Field(..., description="Name or title of the procurement tender.")
    tender_source_url: str = Field(..., description="URL where tender was found.")
    match_score: int = Field(..., description="Match score (0-100).")
    matched_requirements: List[str] = Field(..., description="Requirements matched.")
    missing_requirements: List[str] = Field(..., description="Requirements missing.")
    reasoning: str = Field(..., description="Explanation of the evaluation.")

class FinalReport(BaseModel):
    sme_name: str
    evaluated_tenders: List[TenderMatchResult]