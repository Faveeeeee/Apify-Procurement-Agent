"""Module defines the main entry point for the Apify Actor.

Feel free to modify this file to suit your specific needs.

To build Apify Actors, use the Apify SDK toolkit, read more at the official documentation:
https://docs.apify.com/sdk/python
"""

import asyncio
import os
import logging
from apify import Actor
from langchain_openai import ChatOpenAI
from langchain_apify import ApifyScrapeUrlTool
from langchain_core.messages import SystemMessage, HumanMessage

from .models import FinalReport, TenderMatchResult

SAMPLE_TENDER_FALLBACK = """
TENDER NOTICE: Federal Ministry of Communications & Digital Economy
Title: Provision of Cloud Infrastructure & Enterprise Software Solutions
Location: Abuja / Lagos
Requirements:
1. ISO 27001 Certification required.
2. NITDA Registration mandatory.
3. Minimum 3 years of experience in Software Development or Cloud Migration.
4. Services needed: Software Development, Cloud Migration, Cybersecurity audit.
"""

async def main() -> None:
    async with Actor:
        await Actor.charge('actor-start')

        actor_input = await Actor.get_input() or {}
        sme_profile = actor_input.get("sme_profile")
        target_urls = actor_input.get("target_urls", ["https://tendersnigeria.com"])

        if not sme_profile:
            await Actor.fail(status_message="Missing SME Profile in input JSON.")
            return

        # Read xAI or OpenAI API key from Environment Variables
        xai_key = os.getenv("XAI_API_KEY") or os.getenv("OPENAI_API_KEY")
        if not xai_key:
            await Actor.fail(status_message="API Key is missing in Environment Variables!")
            return

        Actor.log.info("Starting web scraping for procurement opportunities...")
        scraper = ApifyScrapeUrlTool()
        scraped_contents = []

        for url in target_urls:
            try:
                scraped_data = scraper.invoke({"url": url})
                content_str = str(scraped_data)
                if content_str and len(content_str) > 50:
                    scraped_contents.append({"url": url, "content": content_str[:4000]})
                else:
                    scraped_contents.append({"url": url, "content": SAMPLE_TENDER_FALLBACK})
            except Exception as e:
                Actor.log.error(f"Scraping error for {url}: {e}")
                scraped_contents.append({"url": url, "content": SAMPLE_TENDER_FALLBACK})

        # Configure ChatOpenAI to use xAI Grok endpoint
        llm = ChatOpenAI(
            model="grok-4.7",
            api_key=xai_key,
            base_url="https://api.x.ai/v1",
            temperature=0
        )
        structured_llm = llm.with_structured_output(FinalReport)

        system_prompt = """
        You are an expert Procurement AI Agent evaluating procurement tenders in Nigeria for SMEs.
        Extract valid tenders found in the scraped content, analyze them against the SME's credentials and services, 
        and calculate a match score (0-100). List exact matched requirements and missing requirements.
        """

        user_prompt = f"""
        SME PROFILE:
        {sme_profile}

        SCRAPED TENDER DATA:
        {scraped_contents}
        """

        Actor.log.info("Running match evaluation with Grok 4.7...")
        report: FinalReport = await structured_llm.ainvoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ])

        results_dict = report.model_dump()

        store = await Actor.open_key_value_store()
        await store.set_value('response.json', results_dict)

        await Actor.push_data(results_dict)
        await Actor.charge('task-completed')
        
        Actor.log.info("Successfully completed evaluation and saved results to dataset!")

if __name__ == "__main__":
    asyncio.run(main())